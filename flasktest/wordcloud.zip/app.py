from flask import Flask, render_template,g,redirect,url_for,request,session,jsonify
import utils

app = Flask(__name__)

@app.route('/show')
def show():
    return render_template("show.html")

@app.route('/main')
def main():
    return render_template("main.html")

@app.route('/time')
def get_time():
    return utils.get_time()

@app.route('/c1')
def get_data():
    import pymysql
    datalist1 = []
    datalist2 = []
    datalist3 = []
    host = 'localhost'
    user = 'root'
    password = '123456'
    db = '雪球基金'
    port = 3306
    try:
        db = pymysql.connect(host=host, user=user, password=password, port=port, db=db)
        cursor = db.cursor()
        sql1 = "select 基金分布.usernum from 基金分布 where name ='合计'"
        sql2 = "select 基金分布.fundnum from 基金分布 where name ='合计'"
        sql3 = "select 基金分布.scale from 基金分布 where name ='合计'"
        cursor.execute(sql1)
        for item in cursor.fetchall():
            datalist1.append(item)
        cursor.execute(sql2)
        for item in cursor.fetchall():
            datalist2.append(item)
        cursor.execute(sql3)
        for item in cursor.fetchall():
            datalist3.append(item)
        #print(datalist1, datalist2, datalist3)
        db.commit()
        #print('数据取出成功！')
    except pymysql.Error as e:
        print('数据取出失败：' + str(e))
        db.rollback()
    db.close()
    return jsonify({"usernum":datalist1[0],"fundnum":datalist2[0],"scale":datalist3[0]})

@app.route("/")
def index():
    return render_template('index.html')

@app.route("/index")
def home():
    return index()

@app.route("/fund")
def fund():
    import pymysql
    datalist = []
    host = 'localhost'
    user = 'root'
    password = '123456'
    db = '雪球基金'
    port = 3306
    try:
        db = pymysql.connect(host=host, user=user, password=password, port=port, db=db)
        cursor = db.cursor()
        sql = "select * from 雪球基金"
        cursor.execute(sql)
        for item in cursor.fetchall():
            datalist.append(item)
            #print(datalist)
        db.commit()
        #print('数据取出成功！')
    except pymysql.Error as e:
        #print('数据取出失败：' + str(e))
        db.rollback()
    db.close()
    return render_template('fund.html',funds=datalist)

@app.route("/word")
def word():
    return render_template('word.html')

@app.route("/team")
def team():
    return render_template('team.html')

@app.route("/designer")
def designer():
    return render_template('designer.html')

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port='5000')