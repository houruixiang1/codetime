import pymysql
datalist = []
host = 'localhost'
user = 'root'
password = '123456'
db = '雪球基金'
port = 3306
try:
    db = pymysql.connect(host=host, user=user, password=password, port=port, db=db)
    cursor = db.cursor()
    sql = "select * from 雪球基金"
    cursor.execute(sql)
    for item in cursor.fetchall():
        datalist.append(item)
            #print(datalist)
    db.commit()
    print('数据取出成功！')
except pymysql.Error as e:
    print('数据取出失败：' + str(e))
    db.rollback()
db.close()
print(datalist)