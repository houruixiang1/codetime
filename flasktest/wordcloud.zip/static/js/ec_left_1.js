var ec_center =echarts.init(document.getElementById('l1'));
var option = {
            title: {
                text: '基金top10',
//                textStyle: {
//                    color: 'white',
//                    fontSize: 20
//                }
            },
            tooltip: {
            },
            legend: {
                data:['市值']
            },
            xAxis: {
                data: ["贵州茅台","工商银行","建设银行","招商银行","中国平安",
                        "农业银行","中国人寿","中国银行","中国石油","中国中免"]
            },
            yAxis: {},
            series: [{
                name: '市值',
                type: 'bar',
                color: 'blue',
                data: [27.52329379800, 18.53312536863, 17.02574756680, 14.29965245577, 12.87111797678,
                      11.72443163475,10.05092909800,9.21433786584,8.63859015301,6.19676688155]
            }]
        };
        ec_center.setOption(option);