var ec_center =echarts.init(document.getElementById('r1'));
var option = {
    title: {
        text: '雪球基金评论来源',
        left: 'center'
    },
    tooltip: {
        trigger: 'item'
    },
    legend: {
        orient: 'vertical',
        left: 'left',
    },
    series: [
        {
            name: '评论来源',
            type: 'pie',
            radius: '50%',
            data: [
                {value: 123, name: '雪球'},
                {value: 124, name: 'Android'},
                {value: 83, name: 'iPhone'},
            ],
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            }
        }
    ]
};
        ec_center.setOption(option);