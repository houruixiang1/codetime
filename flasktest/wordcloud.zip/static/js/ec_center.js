var ec_center = echarts.init(document.getElementById('c2'));

var option = {
      title: {

        left: 'center'
      },
      tooltip: {//图形编辑
        trigger: 'item'//点对应数值
      },
      legend: {//
        orient: 'vertical',//布局方式
        left: 'left',
        data: ['中国疫情图']
      },
      visualMap: {//视觉映射组件
        type: 'piecewise',
        pieces: [
          { min: 1000, max: 1000000, label: '大于等于30000支', color: '#372a28' },
          { min: 500, max: 999, label: '10000-29999支', color: '#4e160f' },
          { min: 100, max: 499, label: '1000-9999支', color: '#974236' },
          { min: 10, max: 99, label: '100-999支', color: '#ee7263' },
          { min: 1, max: 9, label: '1-99支', color: '#f5bba7' },
        ],
        color: ['#E0022B', '#E09107', '#A3E00B']
      },
      toolbox: {
        show: true,//显示策略
        orient: 'vertical',//布局方式
        left: 'right',//水平
        top: 'center',//垂直安放位置
        feature: {
          mark: { show: true },
          dataView: { show: true, readOnly: false },
          restore: { show: true },
          saveAsImage: { show: true }
        }
      },
      roamController: {
        show: true,
        left: 'right',
        mapTypeControl: {
          'china': true
        }
      },
      series: [
        {
          name: '基金数',
          type: 'map',
          mapType: 'china',
          roam: false,
          label: {
            show: true,
            color: 'rgb(249, 249, 249)'
          },
          data: [
            {
              name: '北京',
              value: 17005
            }, {
              name: '天津',
              value: 2048
            }, {
              name: '上海',
              value: 29691
            }, {
              name: '重庆',
              value: 515
            }, {
              name: '河北',
              value: 235
            }, {
              name: '河南',
              value: 408
            }, {
              name: '云南',
              value: 168
            }, {
              name: '辽宁',
              value: 359
            }, {
              name: '黑龙江',
              value: 97
            }, {
              name: '湖南',
              value: 768
            }, {
              name: '安徽',
              value: 918
            }, {
              name: '山东',
              value: 2037
            }, {
              name: '新疆',
              value: 339
            }, {
              name: '江苏',
              value: 3842
            }, {
              name: '浙江',
              value: 12817
            }, {
              name: '江西',
              value: 741
            }, {
              name: '湖北',
              value: 864
            }, {
              name: '广西',
              value: 220
            }, {
              name: '甘肃',
              value: 59
            }, {
              name: '山西',
              value: 144
            }, {
              name: '内蒙古',
              value: 128
            }, {
              name: '陕西',
              value: 678
            }, {
              name: '吉林',
              value: 119
            }, {
              name: '福建',
              value: 2558
            }, {
              name: '贵州',
              value: 235
            }, {
              name: '广东',
              value: 25093
            }, {
              name: '青海',
              value: 35
            }, {
              name: '西藏',
              value: 1417
            }, {
              name: '四川',
              value: 1105
            }, {
              name: '宁夏',
              value: 104
            }, {
              name: '海南',
              value: 278
            }, {
              name: '台湾',
              value: 1500
            }, {
              name: '香港',
              value: 15140
            }, {
              name: '澳门',
              value: 25000
            }
          ]
        }
      ]
    };

    //使用指定的配置项和数据显示图表
    ec_center.setOption(option);
