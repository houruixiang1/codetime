var ec_center =echarts.init(document.getElementById('r2'));
var labelRight = {
    position: 'right'
};
var option = {
    title: {
        text: '当前价top10基金的涨跌幅变化',
//        subtext: 'From ExcelHome',
//        sublink: 'http://e.weibo.com/1341556070/AjwF2AgQm'
    },
    tooltip: {
        trigger: 'axis',
        axisPointer: {            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
        }
    },
    grid: {
        top: 80,
        bottom: 30
    },
    xAxis: {
        type: 'value',
        position: 'top',
        splitLine: {
            lineStyle: {
                type: 'dashed'
            }
        }
    },
    yAxis: {
        type: 'category',
        axisLine: {show: false},
        axisLabel: {show: false},
        axisTick: {show: false},
        splitLine: {show: false},
        data: ['包钢股份', '农业银行', '兴业证券', '重庆钢铁', '紫金矿业', '诺德股份', '洛阳钼业', '物产中大', '中国银行', '和邦生物']
    },
    series: [
        {
            name: '涨跌幅',
            type: 'bar',
            stack: '总量',
            label: {
                show: true,
                formatter: '{b}'
            },
            data: [
                {value: -1.23, label: labelRight},
                {value: 0.9, label: labelRight},
                {value: 2.35, label: labelRight},
                {value: -0.74, label: labelRight},
                {value: -0.98, label: labelRight},
                4.34,
                {value: -2.86, label: labelRight},
                -3.2,
                {value: -0.32, label: labelRight},
                -2.38
            ]
        }
    ]
};
        ec_center.setOption(option);